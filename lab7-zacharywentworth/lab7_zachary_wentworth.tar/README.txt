The interleaving can be seen by the alternation of the prints i.e 040404 and if 
you were to comment out one of the processes in user3.c the time to complete 
will be the same as the time it takes to run both processes when running 
"time stackl os > out" 
